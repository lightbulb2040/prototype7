<?php

/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| Here is where you can register all of the routes for an application.
| It's a breeze. Simply tell Laravel the URIs it should respond to
| and give it the controller to call when that URI is requested.
|
*/

/*
|   Static Pages
*/


Route::get('/', ['as' => 'home', 'uses'  =>  'HomeController@index']);

/*
|   End of Static Pages
*/


//MITE NEED TO SECURE THESE.....>>>

Route::group(array('middleware' => 'auth'), function() {

    Route::get('/signout', [
        'as'    =>  'account-sign-out',
        'uses'  =>  'AccountController@getSignOut'

    ]);

    Route::get('/packages', ['as' => 'packages', 'uses'  =>  'HomeController@packages']);

    Route::get('/products', ['as' => 'products', 'uses'  =>  'HomeController@products']);

});

/*
|   Unaunthenticated group
*/
Route::group(array('middleware' => 'guest'), function() {
    
    /* 
    |   Signup Page 
    */
	Route::get('/signup', [
	    'as' => 'account-create',
	    'uses' => 'AccountController@create']);
     
	/*
    |   Creates an account (POST)
    */
    Route::post('/signup', array(
        'as' => 'account-create-post',
        'uses' => 'AccountController@store'
    ));

    /*
    |   Log In (GET)
    */
    Route::get('/login', array(
        'as' => 'login',
        'uses' => 'AccountController@login'
    ));

    /*
    |   Sign In (POST)
    */
    Route::post('/login', array(
        'as' => 'login-post',
        'uses' => 'AccountController@postLogin'
    ));  
    
    
    
	
    /*
    |   Activation link (GET)
    */
    Route::get('/account/activate/student/{code}',array(
        'as'   => 'account-activate',
        'uses' => 'AccountController@getActivate'
    ));

    /*
    |   Forgot Password (POST)
    */
    Route::post('/account/forgot-password', array(
        'as' => 'account-forgot-password-post',
        'uses' => 'AccountController@postForgotPassword'
    ));  

    /*
    |   Forgot Password (GET)
    */
    Route::get('/account/forgot-password', array(
        'as' => 'account-forgot-password',
        'uses' => 'AccountController@getForgotPassword'
    ));


    Route::get('/account/recover/{code}', array(
        'as' => 'account-recover',
        'uses' => 'AccountController@getRecover'
    ));
    
});
