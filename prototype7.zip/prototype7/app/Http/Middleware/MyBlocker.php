<?php namespace App\Http\Middleware;

use Closure;

use Auth, Session;

class MyBlocker {

	/**
	 * Handle an incoming request.
	 *
	 * @param  \Illuminate\Http\Request  $request
	 * @param  \Closure  $next
	 * @return mixed
	 */
	public function handle($request, Closure $next)
	{

		if(Auth::user()->check() || Auth::company()->check())
		{
			return $next($request);
		} else {
			Session::flash('loginPopdown', 1);
			return redirect()->guest('/');
		}
		
	}

}
