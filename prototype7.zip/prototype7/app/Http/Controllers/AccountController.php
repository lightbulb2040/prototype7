<?php namespace App\Http\Controllers;

use Validator, Input, Redirect, Hash, Mail, URL, Auth, Config, Session, Flash; 
use \App\User;
use \App\Company;
use App\Http\Requests;


class AccountController extends Controller {

	/*
	|--------------------------------------------------------------------------
	| Home Controller
	|--------------------------------------------------------------------------
	|
	| This controller renders your application's "dashboard" for users that
	| are authenticated. Of course, you are free to change or remove the
	| controller as you wish. It is just here to get your app started!
	|
	*/

	/**
	 * Create Page For User To Register
	 *
	 * @return Response
	 */
    public function create()
    {
        return view('account.create');
    }

    /**
     * Create User Account
     *
     * @return Response
     */
    public function store(Requests\CreateUserRequest $request) {
    
        $email      = $request->email;
        $firstname  = $request->fisrtname;
        
        // Activation Code
        $code       = str_random(60); 

        Mail::send('emails.account.activate', ['link' => URL::route('account-activate', $code), 'firstname' => $firstname], function($message) use ($email, $firstname) {
                $message->to($email, $firstname)->subject('Activate Your Account');
            });

        if(count(Mail::failures()) > 0 ) {

            Flash::error('There was a problem with the signup process. Please try again or contact us and we will be glad to help you.');
            return redirect()->back();

        }
        else{

            $user = User::create([
                'email'         => $email,
                'firstname'     => $request->firstname,
                'lastname'      => $request->lastname,
                'password'      => Hash::make($request->password),
            ]);
            
            //User Saved Here....            
            $user->code = $code;
            $user->active = 0;
            $user->save();

            Flash::success('Your account has been created! Please check your email for the verification code');
            return redirect()->route('login');

        }             
        
    }

    public function getActivate($code) {
        $user = User::where('code', '=', $code)->where('active', '=', 0);
        
        if($user->count()) {
            $user = $user->first();   
            
            // update user to active state
            $user->active   = 1;
            $user->code     = '';
            
            if($user->save()) {
                Flash::success('Your account has been activated! You can now sign in.');
                $url = URL::route('login');
                return redirect()->to($url);

            }
        }
        
        Flash::error('We could not activate your account. Try again later or contact us and we will be glad to help you.');
        return redirect()->route('/');
        
    }


	public function login() {

        return view('account.login');

    }
    
    public function postLogin() {

        $validator = Validator::make(Input::all(),
            array(
                 'email'            => 'required|email',
                 'password'         => 'required',
            ));
        
        if($validator->fails()) {
            return  redirect()->route('login')
                    ->withErrors($validator)
                    ->withInput();
        } else {
                
            $remember = (Input::has('remember')) ? true : false;
            
            $auth = Auth::attempt(array(
                'email' => Input::get('email'),
                'password' => Input::get('password'),
                'active'    => 1
            ), $remember);

                //dd($auth);
                
            if($auth) {
				Session::put('userType', 'Student');
                
                //Redirect to intended page
                Flash::success('You have successfully logged in!!');
                return redirect()->intended('/');
					
					
            } else {
                
                Flash::error('Email/Password wrong or account not activated, please check your email for activating your account or hit forgot password to reset password.');
                return redirect()->route('login');
                
            }    
            
        }
        
        Flash::error('There was a problem signing you in.');
        return redirect()->route('login');
    }
    
    public function getSignOut() {
        Auth::logout();
        Session::forget('userType');
        Session::flush();
        Flash::success('You have successfully logged out!!');
        return redirect()->route('home')->with('global', 'You have successfully signed out!!!');;
    }

    public function getCreate() {

        return view('account.create');
        
    }

    public function postCompanyCreate(Requests\CreateCompanyRequest $request) {

        $email      = $request->email;
        $name       = $request->name;
        $password   = $request->password;

        
        
        // Activation Code
        $code       = str_random(60);   
        
        $user = Company::create([
            'email'         => $email,
            'name'          => $request->name,
            'website'       => $request->website,
            'incharge'      => $request->incharge,
            'password'      => Hash::make($password),
            'about'         => $request->about,
            'city_id'       => $request->location,
            'number'        => $request->number
        ]);

        //creating slug
        $specialname = preg_replace('/[^A-Za-z0-9\. -]/', '', $name);
        $specialname = preg_replace('/[[:space:]]+/', '-', $specialname);

        $profile_name = strtolower($specialname). '-' . strtolower(str_random(7));
        

        $user->code = $code;
        $user->active = 0;
        $user->slug = $profile_name;

        $check = $user->save();



        
        if($check) {
            
            Mail::send('emails.account.company.activate', ['link' => URL::route('account-activate-company', $code), 'name' => $name], function($message) use ($user) {
                $message->to($user->email, $user->name)->subject('Activate Your Account');
            });
            
            Flash::success('Your account has been created! Please check your email for the verification code');
            return redirect()->route('company-account-sign-in');
            
        }  

        Flash::error('There was a problem with the signup process. Please try again or contact us and we will be glad to help you.');
        return redirect()->back();

    }
    
    
    
    

    public function getActivateCompany($code) {
        $user = Company::where('code', '=', $code)->where('active', '=', 0);
        
        if($user->count()) {
            $user = $user->first();   
            
            // update user to active state
            $user->active   = 1;
            $user->code     = '';
            
            if($user->save()) {
                Flash::success('Your account has been activated! You can now sign in.');
                Session::flash('loginPopdown', 1);
                $url = URL::route('/') . '#company';
                return redirect()->to($url);
            }
        }
        
        Flash::error('We could not activate your account. Try again later or contact us and we will be glad to help you.');
        return redirect()->route('/');
        
    }
    
    public function getChangePassword() {
    
        return view('account.change');
    }

    public function getCompanyChangePassword() {
    
        return view('account.companychange');
    }
    
    public function postChangePassword() {
        $validator = Validator::make(Input::all(), 
            array(
                'old_password'      => 'required',
                'password'          => 'required|min:6',
                'password_again'    => 'required|same:password'
                
            )
        );
        
        if($validator->fails()){
            $url = URL::route('account-change-password');
                    return Redirect::to($url)->withErrors($validator);
            
        } else {
            
            $user = User::find(Auth::user()->get()->id);
            
            $old_password   = Input::get('old_password');
            $password       = Input::get('password');
            
            if(Hash::check($old_password, $user->getAuthPassword())) {
                $user->password = Hash::make($password);
                
                if($user->save()) {
                    Flash::success('Your Password has been changed!!');
                    $url = URL::route('account-change-password');
                    return Redirect::to($url);
                }
            
            } else {
                    Flash::error('Your Old Password is incorrect');
                    $url = URL::route('account-change-password');
                    return Redirect::to($url);
            }
        }
            Flash::error('Your Password could not be changed');
            $url = URL::route('account-change-password');
            return Redirect::to($url);
    }

    public function postCompanyChangePassword() {
        $validator = Validator::make(Input::all(), 
            array(
                'old_password'      => 'required',
                'password'          => 'required|min:6',
                'password_again'    => 'required|same:password'
                
            )
        );
        
        if($validator->fails()){
            $url = URL::route('company-change-password');
                    return Redirect::to($url)->withErrors($validator);
            
        } else {
            
            $user = Company::find(Auth::company()->get()->id);
            
            $old_password   = Input::get('old_password');
            $password       = Input::get('password');
            
            if(Hash::check($old_password, $user->getAuthPassword())) {
                $user->password = Hash::make($password);
                
                if($user->save()) {
                    Flash::success('Your Password has been changed!!');
                    $url = URL::route('company-change-password');
                    return Redirect::to($url);
                }
            
            } else {
                    Flash::error('Your Old Password is incorrect');
                    $url = URL::route('company-change-password');
                    return Redirect::to($url);
            }
        }
            Flash::error('Your Password could not be changed');
            $url = URL::route('company-change-password');
            return Redirect::to($url);
    }
    
    public function getForgotPassword() {
        return view('account.forgot');
    }

    public function getCompanyForgotPassword() {
        return view('account.companyforgot');
    }
    
    public function postForgotPassword() {
        $validator = Validator::make(Input::all(),
            array(
                'email' => 'required|email'
            )
        );
        
        if($validator->fails()) {
            return redirect()->route('account-forgot-password')
            ->withErrors($validator)
            ->withInput();
                    
        } else {
            
            $user = User::where('email', '=', Input::get('email'))->get();
            
            if($user->count()) {
                $user                   = $user->first();
                
                //Generate new code and password
                $code                   = str_random(60);
                $password               = str_random(10);
                
                $user->code             = $code;
                $user->password_temp    = Hash::make($password);
                
                if($user->save()){
                    
                    Mail::send('emails.account.forgot', array('link' => URL::route('account-recover', $code), 'username' => $user->firstname, 'password' => $password), function($message) use ($user) {
                        $message->to($user->email, $user->firstname)->subject('Your New Password');
                    });
                    
                    Flash::success('We have sent you an email with a reset link and a new password.');
                    return redirect()->route('student-home');
                
                }
            }
        
        }
        Flash::error('This account does not exist');
        return redirect()->route('account-forgot-password');
    }

    public function postCompanyForgotPassword() {
        $validator = Validator::make(Input::all(),
            array(
                'email' => 'required|email'
            )
        );
        
        if($validator->fails()) {
            return redirect()->route('company-forgot-password')
            ->withErrors($validator)
            ->withInput();
                    
        } else {
            
            $user = Company::where('email', '=', Input::get('email'))->get();
            
            if($user->count()) {
                $user                   = $user->first();
                
                //Generate new code and password
                $code                   = str_random(60);
                $password               = str_random(10);
                
                $user->code             = $code;
                $user->password_temp    = Hash::make($password);
                
                if($user->save()){
                    
                    Mail::send('emails.account.forgot', array('link' => URL::route('company-recover', $code), 'username' => $user->name, 'password' => $password), function($message) use ($user) {
                        $message->to($user->email, $user->name)->subject('Your New Password');
                    });
                    
                    Flash::success('We have sent you an email with a reset link and a new password.');
                    return redirect()->route('company-home');
                
                }
            }
        
        }
        Flash::error('This account does not exist');
        return redirect()->route('account-forgot-password');
    }
    
    public function getRecover($code) {
        $user = User::where('code', '=', $code)
            ->where('password_temp', '!=', '');
        
        if($user->count()) {
            $user = $user->first();
            
            $user->password         = $user->password_temp;
            $user->password_temp    = '';
            $user->code             = '';
            
            if($user->save()) {
                Flash::success('Your account has been recovered, you can sign in with your new password');
                Session::flash('loginPopdown', 1);
                $url = URL::route('/') . '#student';
                return redirect()->to($url);
                
            }
        }
        Flash::error('Could not recover your account. Try again later or contact us and we will be glad to help you.');
        return redirect()->route('student-home');
        
    }

    public function getCompanyRecover($code) {
        $user = Company::where('code', '=', $code)
            ->where('password_temp', '!=', '');
        
        if($user->count()) {
            $user = $user->first();
            
            $user->password         = $user->password_temp;
            $user->password_temp    = '';
            $user->code             = '';
            
            if($user->save()) {
                Flash::success('Your account has been recovered and you can sign in with your new password');
                Session::flash('loginPopdown', 1);
                $url = URL::route('/') . '#company';
                return redirect()->to($url);
                
            }
        }
        
        Flash::error('Could not recover your account. Try again later or contact us and we will be glad to help you.');
        return redirect()->route('company-home');
        
    }

}
