

        <div class="col-sm-6 col-md-4">
            <div class="login-bottom">
                <h2>Register</h2>
                {!! Form::open(['route' => 'account-create-post']) !!}
                <div class="col-md-12">
                    
                    <div class="login-mail">
                        {!! Form::text('firstname', '', array('placeholder' => 'First Name.', 'id' => 'firstname', Input::old('firstname'))) !!}
                        @if($errors->has('firstname'))
                            <p class="form-error">{{ $errors->first('firstname') }} <span class="glyphicon glyphicon-remove-circle"></span> </p>
                        @endif
                    </div>
                    
                    <div class="login-mail">
                        {!! Form::text('lastname', '', array('placeholder' => 'Last Name', 'id' => 'lastname', Input::old('lastname'))) !!}
                        @if($errors->has('lastname'))
                            <p class="form-error">{{ $errors->first('lastname') }} <span class="glyphicon glyphicon-remove-circle"></span> </p>
                        @endif
                    
                    </div>
                    <div class="login-mail">
                        {!! Form::text('email', '', array('placeholder' => 'Email.', 'id' => 'email', Input::old('email'))) !!}
                        @if($errors->has('email'))
                            <p class="form-error">{{ $errors->first('email') }} <span class="glyphicon glyphicon-remove-circle"></span> </p>
                        @endif
                    </div>
                    <div class="login-mail">
                        {!! Form::password('password', array('placeholder' => 'Password.', 'id' => 'password')) !!}
                        @if($errors->has('password'))
                            <p class="form-error">{{ $errors->first('password') }} <span class="glyphicon glyphicon-remove-circle"></span> </p>
                        @endif
                        
                        
                    </div>
                    <div class="login-mail">
                        {!! Form::password('password_again', array('placeholder' => 'Retype Password.', 'id' => 'password_again')) !!}
                        @if($errors->has('password_again'))
                            <p class="form-error">{{ $errors->first('password_again') }} <span class="glyphicon glyphicon-remove-circle"></span> </p>
                        @endif
                        
                    </div>
<!--
                      <a class="news-letter" href="#">
                         <label class="checkbox1"><input type="checkbox" name="checkbox"><i> </i>I agree with the terms</label>
                       </a>
-->

                </div>
                <div class="col-md-12 login-do">
                    <label class="hvr-shutter-in-horizontal login-sub">
                        <input type="submit" value="Register">
                    </label>
                </div>
                <div class='form-group'>
                    <div class="g-recaptcha" id="g-recaptcha-student"></div>
                </div>
                {!! Form::close() !!}
                <div class="clearfix"> </div>
            </div>
        </div>

