<!DOCTYPE HTML>
<html>
<head>
<title>| Resume</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<link href="{{ asset('css/app.css') }}" rel='stylesheet' type='text/css' />
<!-- Custom Theme files -->
<script type="text/javascript"  src="{{ asset('js/jquery.min.js') }}"> </script>
<script type="text/javascript"  src="{{ asset('js/bootstrap.min.js') }}"> </script>
  
<!-- Mainly scripts -->
<script type="text/javascript" src="{{ asset('js/jquery.metisMenu.js') }}"></script>
<script type="text/javascript" src="{{ asset('js/jquery.slimscroll.min.js') }}"></script>
<script type="text/javascript" src="{{ asset('js/custom.js') }}"></script>
<script type="text/javascript" src="{{ asset('js/screenfull.js') }}"></script>
		<script>
		$(function () {
			$('#supported').text('Supported/allowed: ' + !!screenfull.enabled);

			if (!screenfull.enabled) {
				return false;
			}

			$('#toggle').click(function () {
				screenfull.toggle($('#container')[0]);
			});
		});
		</script>
</head>
<body class="login-screen">
<div class="container-fluid-x">
    <div class="login-bottom logo-header">
        <div class="col-md-3 col-sm-2 col-sm-4 text-center">
            <img class="logo" src="{{ asset('images/logo.png') }}" height="100px" >
        </div>
{!! Form::open(['route' => 'login-post']) !!} 
        <div class="col-md-offset-2 col-md-3 col-sm-4">
            <div class="login-mail">
                {!! Form::text('email', '', array('placeholder' => 'Email.', 'id' => 'email', Input::old('email'))) !!}
                @if($errors->has('email'))
            <p class="form-error">{{ $errors->first('email') }} <span class="glyphicon glyphicon-remove-circle"></span> </p>
        @endif
            </div>
        </div>

        <div class="col-md-3 col-sm-4">
            <div class="login-mail">
                {!! Form::password('password', array('placeholder' => 'Password.', 'id' => 'password')) !!}
                    @if($errors->has('password'))
                        <p class="form-error">{{ $errors->first('password') }} <span class="glyphicon glyphicon-remove-circle"></span> </p>
                    @endif

            </div>
        </div>

        <div class="col-md-1 col-sm-2 col-xs-12 side-padding">
            <label class="hvr-shutter-in-horizontal login-do">
                <input type="submit" value="login">
            </label>

        </div>
        <div class="clearfix"> </div>
        {!! Form::close() !!}
    </div>
</div>
<div class="container">
    <div class="row">
        <div class="col-sm-6 col-md-8">
            <div class="login-bottom">
                @if (Session::has('flash_notification.message'))
                    <div class="alert alert-{{ Session::get('flash_notification.level') }}">
                        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                        <div class="flash-text">{{ Session::get('flash_notification.message') }}</div>
                    </div>
                @endif
                <h1>Need Some Fancy Text</h1><hr/>
                <p>
                    Let's keep some things to explain the need for the resume online stuff. Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>
            </div>
        </div>
        @include('account.create')
    </div>
</div>
</body>
</html>