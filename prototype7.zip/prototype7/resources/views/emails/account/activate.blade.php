Hello {{ $firstname }},<br><br>

Please activate your account using the following link.<br><br>

-----<br>
<a href="{{ $link }}">Click Here to Activate</a><br>
------