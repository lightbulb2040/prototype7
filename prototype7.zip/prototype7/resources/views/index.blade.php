hahaha

@if(Auth::check())
haha
@endif